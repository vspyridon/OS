
#!/bin/bash

current_time=$(date +%s)
echo $current_time
echo $((current_time*2))
for i in {1..20}
do
	echo "$i"
done
